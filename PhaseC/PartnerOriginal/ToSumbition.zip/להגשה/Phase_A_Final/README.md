# Iron Shield - Armory Management System
## פרויקט בסיסי נתונים - שלב א

---

## שער

| | |
|---|---|
| **שם מגיש** | _______________ |
| **מערכת** | Iron Shield - מערכת ניהול נשקייה |
| **יחידה** | חטיבת מילואים - נשקייה |

---

## תוכן עניינים

1. [מבוא](#מבוא)
2. [אפיון מסכים](#אפיון-מסכים)
3. [תרשים ERD](#תרשים-erd)
4. [תרשים DSD](#תרשים-dsd)
5. [החלטות עיצוב](#החלטות-עיצוב)
6. [הכנסת נתונים](#הכנסת-נתונים)
7. [גיבוי ושחזור](#גיבוי-ושחזור)

---

## מבוא

מערכת **Iron Shield** נועדה לנהל את פעילות הנשקייה בחטיבת מילואים.
המערכת מאפשרת מעקב מלא אחר הנשקים, התחמושת, החיילים והאחזקה ביחידה.

### נתונים הנשמרים במערכת

- **חיילים** - פרטי כל חייל ביחידה: שם, דרגה, מחלקה, תאריך גיוס
- **נשקים** - מלאי מלא של הנשקים: מספר סידורי, דגם, סוג, סטטוס
- **הקצאת נשקים** - רישום מי מחזיק איזה נשק, מתי קיבל ומתי החזיר
- **תחמושת** - סוגי תחמושת, כמויות במלאי ורמות מינימום
- **הוצאת תחמושת** - מעקב אחר כל הוצאת תחמושת לחייל עם תאריך ומטרה
- **אחזקה** - יומן תחזוקת נשקים: תאריך, סוג טיפול, טכנאי, ותוצאה

### פונקציונאליות עיקרית

- רישום ומעקב אחר הקצאת נשקים לחיילים
- ניהול מלאי תחמושת כולל התראות על מלאי נמוך
- יומן אחזקה לכל נשק
- דוחות: נשקים מחוץ לנשקייה, צריכת תחמושת, היסטוריית אחזקה

---

## אפיון מסכים

המסכים נוצרו בעזרת **Google AI Studio**.
קובץ המסכים: [`system_mockup.html`](system_mockup.html)

המערכת כוללת 7 מסכים:

| מסך | תיאור |
|---|---|
| Dashboard | סיכום מצב הנשקייה - נשקים, תחמושת, התראות |
| Soldiers Management | ניהול רשימת החיילים |
| Weapons Inventory | מלאי הנשקים וסטטוסם |
| Issue & Return | שחרור והחזרת נשקים |
| Ammunition | ניהול מלאי תחמושת |
| Maintenance Log | יומן אחזקה |
| Reports | דוחות מערכת |

---

## תרשים ERD

![ERD Diagram](ERD_diagram.png)

---

## תרשים DSD

![DSD Diagram](DSD_diagram.png)

---

## החלטות עיצוב

### ישויות ראשיות (7)
`SOLDIER`, `UNIT`, `WEAPON`, `WEAPON_ASSIGNMENT`, `AMMUNITION`, `AMMO_ISSUE`, `MAINTENANCE`

### טבלאות ENUM (5, לא נספרות)
`RANK`, `WEAPON_TYPE`, `WEAPON_STATUS`, `AMMO_TYPE`, `MAINTENANCE_TYPE`

### שדות DATE משמעותיים
| שדה | טבלה | משמעות |
|---|---|---|
| `enlistment_date` | SOLDIER | תאריך גיוס החייל |
| `entry_date` | WEAPON | תאריך כניסת הנשק למלאי |
| `assignment_date` | WEAPON_ASSIGNMENT | תאריך קבלת הנשק |
| `return_date` | WEAPON_ASSIGNMENT | תאריך החזרת הנשק (NULL אם עדיין מוחזק) |
| `issue_date` | AMMO_ISSUE | תאריך הוצאת תחמושת |
| `maintenance_date` | MAINTENANCE | תאריך ביצוע האחזקה |

### אילוצים (Constraints)
| טבלה | אילוץ | הסבר |
|---|---|---|
| SOLDIER | `LENGTH(phone) >= 9` | מספר טלפון תקין |
| SOLDIER | `enlistment_date >= '1948-01-01'` | תאריך גיוס הגיוני |
| WEAPON | `manufacture_year BETWEEN 1900 AND 2100` | שנת ייצור סבירה |
| WEAPON_ASSIGNMENT | `return_date >= assignment_date` | לא ניתן להחזיר לפני קבלה |
| AMMUNITION | `stock_quantity >= 0` | מלאי לא יכול להיות שלילי |
| AMMO_ISSUE | `quantity > 0` | כמות הוצאה חייבת להיות חיובית |

### פתרון Circular Dependency
בין `UNIT` ו-`SOLDIER` קיימת תלות מעגלית:
חייל שייך ליחידה ← יחידה יש לה מפקד שהוא חייל.
**פתרון:** UNIT נוצרת ללא FK למפקד, ולאחר יצירת SOLDIER מבוצע `ALTER TABLE UNIT ADD CONSTRAINT`.

---

## הכנסת נתונים

### שיטה 1 - INSERT ידני
הכנסה ידנית של טבלאות ה-ENUM ו-UNIT (38 רשומות).
קובץ: [`insertTables_manual.sql`](insertTables_manual.sql)

![Manual INSERT Screenshot](screenshots/insert%20tables%20screenshot.png)

### שיטה 2 - סקריפט Python
סקריפט שמייצר נתונים אקראיים ריאליסטיים.
קובץ: [`Programing/generate_data.py`](Programing/generate_data.py)

| טבלה | רשומות |
|---|---|
| SOLDIER | 600 |
| WEAPON | 600 |
| WEAPON_ASSIGNMENT | 20,000 |
| AMMUNITION | 500 |
| AMMO_ISSUE | 20,000 |
| MAINTENANCE | 500 |

![Python Screenshot](screenshots/insert%20soldier%20screenshot.png)

### שיטה 3 - mockaroo
שימוש באתר [mockaroo.com](https://mockaroo.com) לייצור נתונים אקראיים.
קובץ: [`mockarooFiles/soldier.mockaroo`](mockarooFiles/soldier.mockaroo)
100 רשומות נוספות לטבלת SOLDIER.

![Mockaroo Screenshot](screenshots/mockaroo%20screenshot.png)

---

## סיכום נתונים

| טבלה | סה"כ רשומות |
|---|---|
| RANK | 8 |
| WEAPON_TYPE | 6 |
| WEAPON_STATUS | 4 |
| AMMO_TYPE | 5 |
| MAINTENANCE_TYPE | 5 |
| UNIT | 10 |
| SOLDIER | 700 |
| WEAPON | 600 |
| WEAPON_ASSIGNMENT | 20,000 |
| AMMUNITION | 500 |
| AMMO_ISSUE | 20,000 |
| MAINTENANCE | 500 |

---

## גיבוי ושחזור

הגיבוי בוצע באמצעות `pg_dump` של PostgreSQL.

```bash
pg_dump iron_shield > backup_2026-03-20.sql
```

קובץ הגיבוי: [`backup_2026-03-20.sql`](backup_2026-03-20.sql)
הגיבוי כולל את מבנה הטבלאות והנתונים המלאים ומאפשר שחזור מלא של המערכת.

![Backup Screenshot](screenshots/backup_screenshot.png)
