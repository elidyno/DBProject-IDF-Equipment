-- ============================================================
-- Iron Shield - Armory Management System
-- createTables.sql
-- ============================================================

-- ENUM / Lookup Tables (no dependencies)

CREATE TABLE RANK
(
  rank_id   INT          NOT NULL,
  rank_name VARCHAR(30) NOT NULL,
  PRIMARY KEY (rank_id)
);

CREATE TABLE WEAPON_TYPE
(
  type_id   INT          NOT NULL,
  type_name VARCHAR(50) NOT NULL,
  PRIMARY KEY (type_id)
);

CREATE TABLE WEAPON_STATUS
(
  status_id   INT          NOT NULL,
  status_name VARCHAR(30) NOT NULL,
  PRIMARY KEY (status_id)
);

CREATE TABLE AMMO_TYPE
(
  ammo_type_id INT          NOT NULL,
  type_name    VARCHAR(50) NOT NULL,
  PRIMARY KEY (ammo_type_id)
);

CREATE TABLE MAINTENANCE_TYPE
(
  maint_type_id INT          NOT NULL,
  type_name     VARCHAR(50) NOT NULL,
  PRIMARY KEY (maint_type_id)
);

-- ============================================================
-- UNIT - created WITHOUT commander FK to avoid circular dependency
-- The FK is added after SOLDIER is created (see ALTER TABLE below)
-- ============================================================

CREATE TABLE UNIT
(
  unit_id       INT          NOT NULL,
  unit_name     VARCHAR(50) NOT NULL,
  company       VARCHAR(30) NOT NULL,
  commander_id  INT,
  PRIMARY KEY (unit_id)
);

-- ============================================================
-- SOLDIER - depends on RANK, UNIT
-- ============================================================

CREATE TABLE SOLDIER
(
  soldier_id      INT          NOT NULL,
  first_name      VARCHAR(30) NOT NULL,
  last_name       VARCHAR(30) NOT NULL,
  enlistment_date DATE         NOT NULL,
  phone           VARCHAR(15) NOT NULL,
  rank_id         INT          NOT NULL,
  unit_id         INT          NOT NULL,
  PRIMARY KEY (soldier_id),
  CONSTRAINT chk_phone CHECK (LENGTH(phone) >= 9),
  CONSTRAINT chk_enlistment CHECK (enlistment_date >= DATE '1948-01-01'),
  FOREIGN KEY (rank_id) REFERENCES RANK(rank_id),
  FOREIGN KEY (unit_id) REFERENCES UNIT(unit_id)
);

-- Now add the commander FK to UNIT (resolves circular dependency)
ALTER TABLE UNIT
  ADD CONSTRAINT fk_unit_commander
  FOREIGN KEY (commander_id) REFERENCES SOLDIER(soldier_id);

-- ============================================================
-- WEAPON - depends on WEAPON_TYPE, WEAPON_STATUS
-- ============================================================

CREATE TABLE WEAPON
(
  serial_number    VARCHAR(20) NOT NULL,
  model            VARCHAR(50) NOT NULL,
  manufacture_year INT          NOT NULL,
  entry_date       DATE         NOT NULL,
  type_id          INT          NOT NULL,
  status_id        INT          NOT NULL,
  PRIMARY KEY (serial_number),
  CONSTRAINT chk_manufacture_year CHECK (manufacture_year >= 1900 AND manufacture_year <= 2100),
  CONSTRAINT chk_entry_date CHECK (entry_date >= DATE '1948-01-01'),
  FOREIGN KEY (type_id)   REFERENCES WEAPON_TYPE(type_id),
  FOREIGN KEY (status_id) REFERENCES WEAPON_STATUS(status_id)
);

-- ============================================================
-- WEAPON_ASSIGNMENT - depends on SOLDIER, WEAPON
-- ============================================================

CREATE TABLE WEAPON_ASSIGNMENT
(
  assignment_id   INT           NOT NULL,
  assignment_date DATE          NOT NULL,
  return_date     DATE,
  return_reason   VARCHAR(100),
  soldier_id      INT           NOT NULL,
  serial_number   VARCHAR(20)  NOT NULL,
  PRIMARY KEY (assignment_id),
  CONSTRAINT chk_return_date CHECK (return_date IS NULL OR return_date >= assignment_date),
  FOREIGN KEY (soldier_id)    REFERENCES SOLDIER(soldier_id),
  FOREIGN KEY (serial_number) REFERENCES WEAPON(serial_number)
);

-- ============================================================
-- AMMUNITION - depends on AMMO_TYPE
-- ============================================================

CREATE TABLE AMMUNITION
(
  ammo_id        INT          NOT NULL,
  caliber        VARCHAR(20) NOT NULL,
  stock_quantity INT          NOT NULL,
  minimum_stock  INT          NOT NULL,
  ammo_type_id   INT          NOT NULL,
  PRIMARY KEY (ammo_id),
  CONSTRAINT chk_stock    CHECK (stock_quantity >= 0),
  CONSTRAINT chk_min_stock CHECK (minimum_stock >= 0),
  FOREIGN KEY (ammo_type_id) REFERENCES AMMO_TYPE(ammo_type_id)
);

-- ============================================================
-- AMMO_ISSUE - depends on SOLDIER, AMMUNITION
-- ============================================================

CREATE TABLE AMMO_ISSUE
(
  issue_id   INT          NOT NULL,
  quantity   INT          NOT NULL,
  issue_date DATE         NOT NULL,
  purpose    VARCHAR(100) NOT NULL,
  soldier_id INT          NOT NULL,
  ammo_id    INT          NOT NULL,
  PRIMARY KEY (issue_id),
  CONSTRAINT chk_issue_quantity CHECK (quantity > 0),
  FOREIGN KEY (soldier_id) REFERENCES SOLDIER(soldier_id),
  FOREIGN KEY (ammo_id)    REFERENCES AMMUNITION(ammo_id)
);

-- ============================================================
-- MAINTENANCE - depends on WEAPON, SOLDIER, MAINTENANCE_TYPE
-- ============================================================

CREATE TABLE MAINTENANCE
(
  maintenance_id   INT           NOT NULL,
  maintenance_date DATE          NOT NULL,
  description      VARCHAR(200) NOT NULL,
  status_after     VARCHAR(50)  NOT NULL,
  serial_number    VARCHAR(20)  NOT NULL,
  technician_id    INT           NOT NULL,
  maint_type_id    INT           NOT NULL,
  PRIMARY KEY (maintenance_id),
  CONSTRAINT chk_maint_date CHECK (maintenance_date >= DATE '1948-01-01'),
  FOREIGN KEY (serial_number) REFERENCES WEAPON(serial_number),
  FOREIGN KEY (technician_id) REFERENCES SOLDIER(soldier_id),
  FOREIGN KEY (maint_type_id) REFERENCES MAINTENANCE_TYPE(maint_type_id)
);
