-- ============================================================
-- Iron Shield - Armory Management System
-- dropTables.sql
-- Drop in reverse order of creation to respect FK constraints
-- ============================================================

-- Step 1: Remove circular FK from UNIT before dropping SOLDIER
ALTER TABLE UNIT DROP CONSTRAINT fk_unit_commander;

-- Step 2: Drop tables that depend on others first
DROP TABLE MAINTENANCE;
DROP TABLE AMMO_ISSUE;
DROP TABLE WEAPON_ASSIGNMENT;
DROP TABLE AMMUNITION;
DROP TABLE WEAPON;
DROP TABLE SOLDIER;
DROP TABLE UNIT;

-- Step 3: Drop lookup / ENUM tables
DROP TABLE MAINTENANCE_TYPE;
DROP TABLE WEAPON_STATUS;
DROP TABLE WEAPON_TYPE;
DROP TABLE AMMO_TYPE;
DROP TABLE RANK;
