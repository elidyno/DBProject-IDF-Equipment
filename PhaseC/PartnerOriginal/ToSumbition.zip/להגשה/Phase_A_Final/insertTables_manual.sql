-- ============================================================
-- Iron Shield - Armory Management System
-- insertTables_manual.sql
-- Manual INSERT statements for ENUM / Lookup tables + UNIT
-- These are small, stable tables that make sense to insert manually
-- ============================================================

-- RANK
INSERT INTO RANK VALUES (1, 'Private');
INSERT INTO RANK VALUES (2, 'Corporal');
INSERT INTO RANK VALUES (3, 'Sergeant');
INSERT INTO RANK VALUES (4, 'Staff Sergeant');
INSERT INTO RANK VALUES (5, 'Warrant Officer');
INSERT INTO RANK VALUES (6, 'Lieutenant');
INSERT INTO RANK VALUES (7, 'Captain');
INSERT INTO RANK VALUES (8, 'Major');

-- WEAPON_TYPE
INSERT INTO WEAPON_TYPE VALUES (1, 'Assault Rifle');
INSERT INTO WEAPON_TYPE VALUES (2, 'Light Machine Gun');
INSERT INTO WEAPON_TYPE VALUES (3, 'Pistol');
INSERT INTO WEAPON_TYPE VALUES (4, 'Sniper Rifle');
INSERT INTO WEAPON_TYPE VALUES (5, 'Submachine Gun');
INSERT INTO WEAPON_TYPE VALUES (6, 'Grenade Launcher');

-- WEAPON_STATUS
INSERT INTO WEAPON_STATUS VALUES (1, 'Operational');
INSERT INTO WEAPON_STATUS VALUES (2, 'In Maintenance');
INSERT INTO WEAPON_STATUS VALUES (3, 'In Storage');
INSERT INTO WEAPON_STATUS VALUES (4, 'Decommissioned');

-- AMMO_TYPE
INSERT INTO AMMO_TYPE VALUES (1, '5.56mm NATO');
INSERT INTO AMMO_TYPE VALUES (2, '9mm Luger');
INSERT INTO AMMO_TYPE VALUES (3, '7.62mm Link');
INSERT INTO AMMO_TYPE VALUES (4, '12.7mm AP');
INSERT INTO AMMO_TYPE VALUES (5, '40mm Grenade');

-- MAINTENANCE_TYPE
INSERT INTO MAINTENANCE_TYPE VALUES (1, 'Routine Cleaning');
INSERT INTO MAINTENANCE_TYPE VALUES (2, 'Part Replacement');
INSERT INTO MAINTENANCE_TYPE VALUES (3, 'Zeroing');
INSERT INTO MAINTENANCE_TYPE VALUES (4, 'Full Overhaul');
INSERT INTO MAINTENANCE_TYPE VALUES (5, 'Damage Repair');

-- UNIT
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (1,  'Alpha Company',   '1st Battalion');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (2,  'Bravo Company',   '1st Battalion');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (3,  'Charlie Company', '2nd Battalion');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (4,  'Delta Company',   '2nd Battalion');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (5,  'HQ Company',      'Brigade HQ');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (6,  'Support Company', 'Logistics');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (7,  'Recon Platoon',   'Intel');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (8,  'Engineering',     'Support');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (9,  'Signals',         'Support');
INSERT INTO UNIT (unit_id, unit_name, company) VALUES (10, 'Medical',         'Support');
