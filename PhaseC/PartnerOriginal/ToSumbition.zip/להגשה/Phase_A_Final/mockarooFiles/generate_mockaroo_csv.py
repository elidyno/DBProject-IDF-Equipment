"""
Generates CSV files that simulate mockaroo output
Run this to produce the CSV files, then run csv_to_sql.py to get INSERT statements
"""

import csv
import random
from datetime import date, timedelta

random.seed(99)

def rand_date(start, end):
    return start + timedelta(days=random.randint(0, (end - start).days))

# ── SOLDIER extra records (mockaroo style) ────────────────────────────────────
# soldier_id range 2000001+ to avoid collision with Python-generated records

first_names = ["James","John","Robert","Michael","William","David","Joseph","Thomas",
                "Charles","Daniel","Matthew","Anthony","Mark","Donald","Paul","Steven",
                "Andrew","Kenneth","Joshua","George"]
last_names  = ["Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis",
                "Wilson","Taylor","Anderson","Thomas","Jackson","White","Harris","Martin",
                "Thompson","Young","Robinson","Lewis"]

with open("soldiers_mockaroo.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["soldier_id","first_name","last_name","enlistment_date","phone","rank_id","unit_id"])
    for i in range(600):
        sid   = 2000001 + i
        fname = random.choice(first_names)
        lname = random.choice(last_names)
        enl   = rand_date(date(2000,1,1), date(2023,12,31))
        phone = f"05{random.randint(10000000,99999999)}"
        rank  = random.randint(1, 8)
        unit  = random.randint(1, 10)
        w.writerow([sid, fname, lname, enl, phone, rank, unit])

print("soldiers_mockaroo.csv - 600 rows")

# ── AMMUNITION extra records ──────────────────────────────────────────────────
# ammo_id range 1001+ to avoid collision

calibers = ["5.56mm","9mm","7.62mm","12.7mm","40mm"]

with open("ammunition_mockaroo.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["ammo_id","caliber","stock_quantity","minimum_stock","ammo_type_id"])
    for i in range(500):
        aid     = 1001 + i
        atype   = random.randint(1, 5)
        caliber = calibers[atype - 1]
        stock   = random.randint(0, 50000)
        min_s   = random.randint(100, 2000)
        w.writerow([aid, caliber, stock, min_s, atype])

print("ammunition_mockaroo.csv - 500 rows")
