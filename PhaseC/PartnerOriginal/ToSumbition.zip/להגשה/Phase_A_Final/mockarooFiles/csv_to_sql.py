"""
Converts mockaroo CSV files to INSERT SQL statements
Output: insert_from_mockaroo.sql
"""

import csv

def csv_to_inserts(filename, table, columns):
    lines = [f"-- From {filename}"]
    with open(filename, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            vals = []
            for col in columns:
                v = row[col]
                # wrap strings in quotes, leave numbers bare
                try:
                    float(v)
                    vals.append(v)
                except ValueError:
                    # date or string
                    if len(v) == 10 and v[4] == '-':
                        vals.append(f"DATE '{v}'")
                    else:
                        vals.append(f"'{v.replace(chr(39), chr(39)*2)}'")
            lines.append(f"INSERT INTO {table} VALUES ({', '.join(vals)});")
    return lines

lines = [
    "-- ============================================================",
    "-- Iron Shield - Armory Management System",
    "-- insert_from_mockaroo.sql",
    "-- Generated from mockaroo-style CSV files via csv_to_sql.py",
    "-- ============================================================",
    "",
]

lines += csv_to_inserts(
    "soldiers_mockaroo.csv", "SOLDIER",
    ["soldier_id","first_name","last_name","enlistment_date","phone","rank_id","unit_id"]
)
lines.append("")
lines += csv_to_inserts(
    "ammunition_mockaroo.csv", "AMMUNITION",
    ["ammo_id","caliber","stock_quantity","minimum_stock","ammo_type_id"]
)

with open("insert_from_mockaroo.sql", "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("Done! insert_from_mockaroo.sql created")
print("  SOLDIER:     600 records")
print("  AMMUNITION:  500 records")
