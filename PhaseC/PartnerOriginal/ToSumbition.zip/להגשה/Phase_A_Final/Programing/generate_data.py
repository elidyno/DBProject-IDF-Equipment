"""
Iron Shield - Armory Management System
Data Generation Script
Generates INSERT statements for all tables
Output: insert_from_python.sql
"""

import random
from datetime import date, timedelta

OUTPUT_FILE = "insert_from_python.sql"

# ── helpers ──────────────────────────────────────────────────────────────────

def rand_date(start: date, end: date) -> date:
    return start + timedelta(days=random.randint(0, (end - start).days))

def sql_date(d: date) -> str:
    return f"DATE '{d}'"

def esc(s: str) -> str:
    return s.replace("'", "''")

# ── reference data ────────────────────────────────────────────────────────────

RANKS = [
    (1, "Private"),
    (2, "Corporal"),
    (3, "Sergeant"),
    (4, "Staff Sergeant"),
    (5, "Warrant Officer"),
    (6, "Lieutenant"),
    (7, "Captain"),
    (8, "Major"),
]

WEAPON_TYPES = [
    (1, "Assault Rifle"),
    (2, "Light Machine Gun"),
    (3, "Pistol"),
    (4, "Sniper Rifle"),
    (5, "Submachine Gun"),
    (6, "Grenade Launcher"),
]

WEAPON_STATUSES = [
    (1, "Operational"),
    (2, "In Maintenance"),
    (3, "In Storage"),
    (4, "Decommissioned"),
]

AMMO_TYPES = [
    (1, "5.56mm NATO"),
    (2, "9mm Luger"),
    (3, "7.62mm Link"),
    (4, "12.7mm AP"),
    (5, "40mm Grenade"),
]

MAINTENANCE_TYPES = [
    (1, "Routine Cleaning"),
    (2, "Part Replacement"),
    (3, "Zeroing"),
    (4, "Full Overhaul"),
    (5, "Damage Repair"),
]

FIRST_NAMES = [
    "Avi", "Yoni", "David", "Moshe", "Eitan", "Nir", "Tal", "Guy",
    "Rotem", "Liav", "Amit", "Ori", "Ron", "Shai", "Omer", "Yoav",
    "Nadav", "Ben", "Itay", "Lior", "Tamir", "Gal", "Alon", "Dor",
    "Kobi", "Ran", "Noam", "Boaz", "Tzachi", "Ilan",
]

LAST_NAMES = [
    "Cohen", "Levi", "Mizrahi", "Peretz", "Katz", "Friedman", "Shapiro",
    "Weiss", "Goldberg", "Barak", "Arad", "Dagan", "Sharon", "Peres",
    "Haim", "Azulay", "Biton", "Avraham", "Nachum", "Dahan",
    "Ohayon", "Kramer", "Stern", "Frank", "Klein", "Rosen", "Levy",
    "Ben-David", "Mor", "Sela",
]

UNIT_NAMES = [
    ("Alpha Company",   "1st Battalion"),
    ("Bravo Company",   "1st Battalion"),
    ("Charlie Company", "2nd Battalion"),
    ("Delta Company",   "2nd Battalion"),
    ("HQ Company",      "Brigade HQ"),
    ("Support Company", "Logistics"),
    ("Recon Platoon",   "Intel"),
    ("Engineering",     "Support"),
    ("Signals",         "Support"),
    ("Medical",         "Support"),
]

PURPOSES = [
    "Range Training", "Operational Carry", "Initial Kit Issue",
    "Combat Exercise", "Reserve Drill", "Annual Qualification",
]

WEAPON_MODELS = {
    1: ["M4A1", "M16A4", "Tavor X95", "Galil ACE"],
    2: ["Negev SF", "Negev NG7", "MAG 58"],
    3: ["Glock 17", "Glock 19", "Jericho 941"],
    4: ["M24 SWS", "Galatz", "SR-25"],
    5: ["UZI Pro", "MP5", "Micro Tavor"],
    6: ["M203", "Milkor MGL"],
}

# ── generation functions ───────────────────────────────────────────────────────

def gen_enum_tables() -> list[str]:
    lines = ["-- ============================================================",
             "-- ENUM / Lookup Tables",
             "-- ============================================================"]
    for rid, name in RANKS:
        lines.append(f"INSERT INTO RANK VALUES ({rid}, '{esc(name)}');")
    lines.append("")
    for tid, name in WEAPON_TYPES:
        lines.append(f"INSERT INTO WEAPON_TYPE VALUES ({tid}, '{esc(name)}');")
    lines.append("")
    for sid, name in WEAPON_STATUSES:
        lines.append(f"INSERT INTO WEAPON_STATUS VALUES ({sid}, '{esc(name)}');")
    lines.append("")
    for aid, name in AMMO_TYPES:
        lines.append(f"INSERT INTO AMMO_TYPE VALUES ({aid}, '{esc(name)}');")
    lines.append("")
    for mid, name in MAINTENANCE_TYPES:
        lines.append(f"INSERT INTO MAINTENANCE_TYPE VALUES ({mid}, '{esc(name)}');")
    return lines


def gen_units(n: int = 10) -> list[str]:
    lines = ["", "-- ============================================================",
             "-- UNIT (commander_id filled later via UPDATE)",
             "-- ============================================================"]
    for i in range(1, n + 1):
        name, company = UNIT_NAMES[i - 1]
        lines.append(
            f"INSERT INTO UNIT (unit_id, unit_name, company) "
            f"VALUES ({i}, '{esc(name)}', '{esc(company)}');"
        )
    return lines


def gen_soldiers(n: int = 600) -> tuple[list[str], list[int]]:
    lines = ["", "-- ============================================================",
             f"-- SOLDIER ({n} records)",
             "-- ============================================================"]
    ids = list(range(1000001, 1000001 + n))
    random.shuffle(ids)
    soldier_ids = []
    unit_count = len(UNIT_NAMES)

    for i, sid in enumerate(ids):
        fname = random.choice(FIRST_NAMES)
        lname = random.choice(LAST_NAMES)
        rank  = random.choice(RANKS)[0]
        unit  = (i % unit_count) + 1
        enl   = rand_date(date(2000, 1, 1), date(2023, 12, 31))
        phone = f"05{random.randint(10000000, 99999999)}"
        lines.append(
            f"INSERT INTO SOLDIER VALUES "
            f"({sid}, '{esc(fname)}', '{esc(lname)}', "
            f"{sql_date(enl)}, '{phone}', {rank}, {unit});"
        )
        soldier_ids.append(sid)

    return lines, soldier_ids


def update_unit_commanders(soldier_ids: list[int]) -> list[str]:
    lines = ["", "-- Assign a commander to each unit"]
    unit_count = len(UNIT_NAMES)
    for unit_id in range(1, unit_count + 1):
        commander = random.choice(soldier_ids)
        lines.append(
            f"UPDATE UNIT SET commander_id = {commander} WHERE unit_id = {unit_id};"
        )
    return lines


def gen_weapons(n: int = 600) -> tuple[list[str], list[str]]:
    lines = ["", "-- ============================================================",
             f"-- WEAPON ({n} records)",
             "-- ============================================================"]
    serials = []
    used = set()

    for i in range(n):
        while True:
            wtype = random.choice(WEAPON_TYPES)[0]
            model = random.choice(WEAPON_MODELS[wtype])
            serial = f"{model[:2].upper()}-{random.randint(10000, 99999)}"
            if serial not in used:
                used.add(serial)
                break
        status       = random.choice(WEAPON_STATUSES)[0]
        mfg_year     = random.randint(1985, 2022)
        entry        = rand_date(date(1990, 1, 1), date(2023, 6, 30))
        lines.append(
            f"INSERT INTO WEAPON VALUES "
            f"('{esc(serial)}', '{esc(model)}', {mfg_year}, "
            f"{sql_date(entry)}, {wtype}, {status});"
        )
        serials.append(serial)

    return lines, serials


def gen_weapon_assignments(
    soldier_ids: list[int], serials: list[str], n: int = 20000
) -> list[str]:
    lines = ["", "-- ============================================================",
             f"-- WEAPON_ASSIGNMENT ({n} records)",
             "-- ============================================================"]

    for i in range(1, n + 1):
        soldier = random.choice(soldier_ids)
        serial  = random.choice(serials)
        adate   = rand_date(date(2010, 1, 1), date(2024, 6, 30))

        if random.random() < 0.6:          # 60% returned
            rdate  = rand_date(adate, min(adate + timedelta(days=365), date(2024, 12, 31)))
            reason = random.choice(["Exercise ended", "Unit rotation", "Maintenance required",
                                    "Soldier discharged", "Weapon upgrade"])
            lines.append(
                f"INSERT INTO WEAPON_ASSIGNMENT VALUES "
                f"({i}, {sql_date(adate)}, {sql_date(rdate)}, "
                f"'{esc(reason)}', {soldier}, '{esc(serial)}');"
            )
        else:                               # 40% still issued
            lines.append(
                f"INSERT INTO WEAPON_ASSIGNMENT VALUES "
                f"({i}, {sql_date(adate)}, NULL, NULL, "
                f"{soldier}, '{esc(serial)}');"
            )

    return lines


def gen_ammunition(n: int = 500) -> tuple[list[str], list[int]]:
    lines = ["", "-- ============================================================",
             f"-- AMMUNITION ({n} records)",
             "-- ============================================================"]
    ammo_ids = list(range(1, n + 1))
    calibers = {1: "5.56mm", 2: "9mm", 3: "7.62mm", 4: "12.7mm", 5: "40mm"}

    for aid in ammo_ids:
        atype   = random.choice(AMMO_TYPES)[0]
        caliber = calibers[atype]
        stock   = random.randint(0, 50000)
        min_stk = random.randint(100, 2000)
        lines.append(
            f"INSERT INTO AMMUNITION VALUES "
            f"({aid}, '{caliber}', {stock}, {min_stk}, {atype});"
        )

    return lines, ammo_ids


def gen_ammo_issues(
    soldier_ids: list[int], ammo_ids: list[int], n: int = 20000
) -> list[str]:
    lines = ["", "-- ============================================================",
             f"-- AMMO_ISSUE ({n} records)",
             "-- ============================================================"]

    for i in range(1, n + 1):
        soldier = random.choice(soldier_ids)
        ammo    = random.choice(ammo_ids)
        qty     = random.randint(1, 500)
        idate   = rand_date(date(2010, 1, 1), date(2024, 6, 30))
        purpose = random.choice(PURPOSES)
        lines.append(
            f"INSERT INTO AMMO_ISSUE VALUES "
            f"({i}, {qty}, {sql_date(idate)}, '{esc(purpose)}', {soldier}, {ammo});"
        )

    return lines


def gen_maintenance(
    serials: list[str], soldier_ids: list[int], n: int = 500
) -> list[str]:
    lines = ["", "-- ============================================================",
             f"-- MAINTENANCE ({n} records)",
             "-- ============================================================"]
    statuses = ["Operational", "Returned to service", "Awaiting parts", "Decommissioned"]

    for i in range(1, n + 1):
        serial    = random.choice(serials)
        tech      = random.choice(soldier_ids)
        mdate     = rand_date(date(2010, 1, 1), date(2024, 6, 30))
        mtype     = random.choice(MAINTENANCE_TYPES)[0]
        desc      = random.choice([
            "Firing pin replaced", "Barrel cleaned", "Sight adjusted",
            "Stock repaired", "Gas tube replaced", "Full strip and clean",
            "BCG lubricated", "Trigger group serviced",
        ])
        status_af = random.choice(statuses)
        lines.append(
            f"INSERT INTO MAINTENANCE VALUES "
            f"({i}, {sql_date(mdate)}, '{esc(desc)}', '{esc(status_af)}', "
            f"'{esc(serial)}', {tech}, {mtype});"
        )

    return lines


# ── main ──────────────────────────────────────────────────────────────────────

def main():
    random.seed(42)

    all_lines = [
        "-- ============================================================",
        "-- Iron Shield - Armory Management System",
        "-- insert_from_python.sql  (generated by generate_data.py)",
        "-- ============================================================",
        "",
    ]

    all_lines += gen_enum_tables()
    all_lines += gen_units(10)

    soldier_lines, soldier_ids = gen_soldiers(600)
    all_lines += soldier_lines

    all_lines += update_unit_commanders(soldier_ids)

    weapon_lines, serials = gen_weapons(600)
    all_lines += weapon_lines

    all_lines += gen_weapon_assignments(soldier_ids, serials, 20000)

    ammo_lines, ammo_ids = gen_ammunition(500)
    all_lines += ammo_lines

    all_lines += gen_ammo_issues(soldier_ids, ammo_ids, 20000)
    all_lines += gen_maintenance(serials, soldier_ids, 500)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(all_lines))

    print(f"Done! Written to {OUTPUT_FILE}")
    print(f"  SOLDIER:            600 records")
    print(f"  WEAPON:             600 records")
    print(f"  WEAPON_ASSIGNMENT:  20,000 records")
    print(f"  AMMUNITION:         500 records")
    print(f"  AMMO_ISSUE:         20,000 records")
    print(f"  MAINTENANCE:        500 records")


if __name__ == "__main__":
    main()
