-- ============================================================
-- Iron Shield - Armory Management System
-- selectAll.sql
-- SELECT all rows from every table
-- ============================================================

SELECT * FROM RANK;

SELECT * FROM WEAPON_TYPE;

SELECT * FROM WEAPON_STATUS;

SELECT * FROM AMMO_TYPE;

SELECT * FROM MAINTENANCE_TYPE;

SELECT * FROM UNIT;

SELECT * FROM SOLDIER;

SELECT * FROM WEAPON;

SELECT * FROM WEAPON_ASSIGNMENT;

SELECT * FROM AMMUNITION;

SELECT * FROM AMMO_ISSUE;

SELECT * FROM MAINTENANCE;
