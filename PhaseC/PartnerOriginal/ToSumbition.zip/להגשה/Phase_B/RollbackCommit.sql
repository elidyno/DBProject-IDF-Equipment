-- ============================================================
-- Iron Shield - Armory Management System
-- Phase B: RollbackCommit.sql
-- ============================================================
-- Demonstrates transaction control:
--   Part 1 - ROLLBACK: changes are discarded
--   Part 2 - COMMIT:   changes are permanently saved
-- Run each part separately and observe the results.
-- ============================================================


-- ============================================================
-- PART 1: ROLLBACK DEMONSTRATION
-- Scenario: Temporarily restock an ammunition item,
--           then undo the change with ROLLBACK.
-- ============================================================

-- Step 1: Show current stock before the transaction
SELECT
    a.ammo_id,
    at2.type_name   AS ammo_type,
    a.caliber,
    a.stock_quantity,
    a.minimum_stock
FROM AMMUNITION a
JOIN AMMO_TYPE at2 ON a.ammo_type_id = at2.ammo_type_id
WHERE a.ammo_id = 1;

-- Step 2: Begin transaction
BEGIN;

-- Step 3: Update stock quantity
UPDATE AMMUNITION
SET stock_quantity = stock_quantity + 5000
WHERE ammo_id = 1;

-- Step 4: Show state AFTER UPDATE (within transaction - change is visible)
SELECT
    a.ammo_id,
    at2.type_name   AS ammo_type,
    a.caliber,
    a.stock_quantity,
    a.minimum_stock
FROM AMMUNITION a
JOIN AMMO_TYPE at2 ON a.ammo_type_id = at2.ammo_type_id
WHERE a.ammo_id = 1;

-- Step 5: ROLLBACK - discard the change
ROLLBACK;

-- Step 6: Show state AFTER ROLLBACK (should be identical to Step 1)
SELECT
    a.ammo_id,
    at2.type_name   AS ammo_type,
    a.caliber,
    a.stock_quantity,
    a.minimum_stock
FROM AMMUNITION a
JOIN AMMO_TYPE at2 ON a.ammo_type_id = at2.ammo_type_id
WHERE a.ammo_id = 1;

-- Expected: stock_quantity in Step 6 equals stock_quantity in Step 1.


-- ============================================================
-- PART 2: COMMIT DEMONSTRATION
-- Scenario: Update the minimum stock level for an ammo item,
--           then permanently save it with COMMIT.
-- ============================================================

-- Step 1: Show current minimum stock before the transaction
SELECT
    a.ammo_id,
    at2.type_name   AS ammo_type,
    a.caliber,
    a.stock_quantity,
    a.minimum_stock
FROM AMMUNITION a
JOIN AMMO_TYPE at2 ON a.ammo_type_id = at2.ammo_type_id
WHERE a.ammo_id = 1;

-- Step 2: Begin transaction
BEGIN;

-- Step 3: Update minimum stock
UPDATE AMMUNITION
SET minimum_stock = minimum_stock + 100
WHERE ammo_id = 1;

-- Step 4: Show state AFTER UPDATE (within transaction)
SELECT
    a.ammo_id,
    at2.type_name   AS ammo_type,
    a.caliber,
    a.stock_quantity,
    a.minimum_stock
FROM AMMUNITION a
JOIN AMMO_TYPE at2 ON a.ammo_type_id = at2.ammo_type_id
WHERE a.ammo_id = 1;

-- Step 5: COMMIT - save the change permanently
COMMIT;

-- Step 6: Show state AFTER COMMIT (should reflect the update)
SELECT
    a.ammo_id,
    at2.type_name   AS ammo_type,
    a.caliber,
    a.stock_quantity,
    a.minimum_stock
FROM AMMUNITION a
JOIN AMMO_TYPE at2 ON a.ammo_type_id = at2.ammo_type_id
WHERE a.ammo_id = 1;

-- Expected: minimum_stock in Step 6 = minimum_stock from Step 1 + 100.
--           The change persists even after closing and reopening the session.
