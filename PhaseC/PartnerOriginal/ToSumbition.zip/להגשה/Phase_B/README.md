# Iron Shield - Armory Management System
## דוח פרויקט - שלב ב: שאילתות ואילוצים

---

## תוכן עניינים

1. [שאילתות SELECT כפולות (4 זוגות)](#שאילתות-select-כפולות)
2. [שאילתות SELECT נוספות (4)](#שאילתות-select-נוספות)
3. [שאילתות DELETE](#שאילתות-delete)
4. [שאילתות UPDATE](#שאילתות-update)
5. [אילוצים חדשים](#אילוצים-חדשים)
6. [Rollback ו-Commit](#rollback-ו-commit)

---

## שאילתות SELECT כפולות

### שאילתה 1 - חיילים שקיבלו תחמושת מעל הממוצע

**תיאור:** מציאת חיילים שסך כמות התחמושת שקיבלו גדולה מהממוצע בין כל החיילים. מציגה שם, דרגה, יחידה, סך תחמושת, מספר הוצאות, ושנה/חודש/יום של ההוצאה האחרונה.

**צורה A – JOIN + GROUP BY + HAVING:**
```sql
SELECT
    s.soldier_id,
    s.first_name || ' ' || s.last_name     AS full_name,
    r.rank_name,
    u.unit_name,
    SUM(ai.quantity)                        AS total_ammo_received,
    COUNT(ai.issue_id)                      AS number_of_issues,
    EXTRACT(YEAR  FROM MAX(ai.issue_date))  AS last_issue_year,
    EXTRACT(MONTH FROM MAX(ai.issue_date))  AS last_issue_month,
    EXTRACT(DAY   FROM MAX(ai.issue_date))  AS last_issue_day
FROM SOLDIER s
JOIN RANK       r   ON s.rank_id    = r.rank_id
JOIN UNIT       u   ON s.unit_id    = u.unit_id
JOIN AMMO_ISSUE ai  ON s.soldier_id = ai.soldier_id
GROUP BY s.soldier_id, s.first_name, s.last_name, r.rank_name, u.unit_name
HAVING SUM(ai.quantity) > (
    SELECT AVG(soldier_total)
    FROM (SELECT SUM(quantity) AS soldier_total FROM AMMO_ISSUE GROUP BY soldier_id) sub
)
ORDER BY total_ammo_received DESC;
```

![Query 1A](screenshots/query_1a.png)

**צורה B – Correlated Subquery בכל שדה:**
```sql
SELECT
    s.soldier_id,
    s.first_name || ' ' || s.last_name     AS full_name,
    r.rank_name, u.unit_name,
    (SELECT SUM(ai.quantity)   FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id) AS total_ammo_received,
    (SELECT COUNT(ai.issue_id) FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id) AS number_of_issues,
    EXTRACT(YEAR  FROM (SELECT MAX(ai.issue_date) FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id)) AS last_issue_year,
    EXTRACT(MONTH FROM (SELECT MAX(ai.issue_date) FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id)) AS last_issue_month
FROM SOLDIER s
JOIN RANK r ON s.rank_id = r.rank_id
JOIN UNIT u ON s.unit_id = u.unit_id
WHERE (SELECT SUM(ai.quantity) FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id) > (
    SELECT AVG(soldier_total)
    FROM (SELECT SUM(quantity) AS soldier_total FROM AMMO_ISSUE GROUP BY soldier_id) avg_sub
)
ORDER BY total_ammo_received DESC;
```

![Query 1B](screenshots/query_1b.png)

**הבדל ויעילות:**
- **צורה A** מבצעת GROUP BY פעם אחת על כל טבלת AMMO_ISSUE. HAVING מסנן לאחר האגרגציה — סריקה יחידה יעילה.
- **צורה B** מריצה subquery מתואם (correlated) עבור כל שורה ב-SOLDIER — 3 שאילתות נוספות לכל חייל. עבור 700 חיילים = אלפי סריקות נוספות.
- **צורה A מהירה משמעותית** לטבלאות גדולות.

---

### שאילתה 2 - נשקים שהוצאו לחייל וגם עברו אחזקה באותה שנה

**תיאור:** מציאת נשקים שבאותה שנה קלנדרית גם הוקצו לחייל וגם עברו אחזקה. מציגה: מספר סידורי, דגם, סוג נשק, שנת פעילות, חודש אחזקה, סוג אחזקה ושם הטכנאי.

**צורה A – JOIN + EXISTS (ללא כפילויות):**
```sql
SELECT
    w.serial_number,
    w.model,
    wt.type_name                                AS weapon_type,
    ws.status_name                              AS current_status,
    EXTRACT(YEAR  FROM m.maintenance_date)      AS activity_year,
    EXTRACT(MONTH FROM m.maintenance_date)      AS maintenance_month,
    mt.type_name                                AS maintenance_type,
    s.first_name || ' ' || s.last_name         AS technician_name
FROM WEAPON w
JOIN WEAPON_TYPE       wt  ON w.type_id        = wt.type_id
JOIN WEAPON_STATUS     ws  ON w.status_id      = ws.status_id
JOIN MAINTENANCE       m   ON w.serial_number  = m.serial_number
JOIN MAINTENANCE_TYPE  mt  ON m.maint_type_id  = mt.maint_type_id
JOIN SOLDIER           s   ON m.technician_id  = s.soldier_id
WHERE EXISTS (
    SELECT 1 FROM WEAPON_ASSIGNMENT wa
    WHERE wa.serial_number = w.serial_number
      AND EXTRACT(YEAR FROM wa.assignment_date) = EXTRACT(YEAR FROM m.maintenance_date)
)
ORDER BY activity_year DESC, w.serial_number;
```

![Query 2A](screenshots/query_2a.png)

**צורה B – IN Subquery מתואם:**
```sql
SELECT
    w.serial_number, w.model, wt.type_name AS weapon_type,
    m.maintenance_date,
    EXTRACT(YEAR  FROM m.maintenance_date) AS maintenance_year,
    EXTRACT(MONTH FROM m.maintenance_date) AS maintenance_month,
    mt.type_name AS maintenance_type
FROM WEAPON w
JOIN WEAPON_TYPE wt ON w.type_id = wt.type_id
JOIN WEAPON_STATUS ws ON w.status_id = ws.status_id
JOIN MAINTENANCE m ON w.serial_number = m.serial_number
JOIN MAINTENANCE_TYPE mt ON m.maint_type_id = mt.maint_type_id
WHERE w.serial_number IN (
    SELECT serial_number FROM WEAPON_ASSIGNMENT
    WHERE EXTRACT(YEAR FROM assignment_date) = EXTRACT(YEAR FROM m.maintenance_date)
)
ORDER BY maintenance_year DESC, w.serial_number;
```

![Query 2B](screenshots/query_2b.png)

**הבדל ויעילות:**
- **צורה A** משתמשת ב-EXISTS שעוצר בשורה הראשונה התואמת. האופטימייזר יכול לבחור hash/merge join יעיל.
- **צורה B** — ה-IN subquery מתואם (מפנה ל-`m.maintenance_date` מהשאילתה החיצונית), ולכן מורץ מחדש לכל שורת אחזקה — הופך ללולאה מקוננת.
- **צורה A עדיפה** וגם מחזירה יותר מידע (שם הטכנאי וסטטוס הנשק).

---

### שאילתה 3 - יחידות עם צריכת תחמושת מעל הממוצע

**תיאור:** יחידות שחיילים שלהן צרכו ביחד יותר תחמושת מהממוצע בין כלל היחידות. מציגה: שם יחידה, חטיבה, מספר חיילים, סך הוצאות, סך תחמושת, שנות פעילות ראשונה ואחרונה.

**צורה A – JOIN + GROUP BY + HAVING:**
```sql
SELECT
    u.unit_id, u.unit_name, u.company,
    COUNT(DISTINCT s.soldier_id)                AS soldier_count,
    COUNT(ai.issue_id)                          AS total_issues,
    SUM(ai.quantity)                            AS total_ammo_consumed,
    EXTRACT(YEAR FROM MIN(ai.issue_date))       AS first_issue_year,
    EXTRACT(YEAR FROM MAX(ai.issue_date))       AS last_issue_year
FROM UNIT u
JOIN SOLDIER    s   ON u.unit_id    = s.unit_id
JOIN AMMO_ISSUE ai  ON s.soldier_id = ai.soldier_id
GROUP BY u.unit_id, u.unit_name, u.company
HAVING SUM(ai.quantity) > (
    SELECT AVG(unit_total) FROM (
        SELECT SUM(ai2.quantity) AS unit_total
        FROM SOLDIER s2 JOIN AMMO_ISSUE ai2 ON s2.soldier_id = ai2.soldier_id
        GROUP BY s2.unit_id
    ) unit_sub
)
ORDER BY total_ammo_consumed DESC;
```

![Query 3A](screenshots/query_3a.png)

**צורה B – Derived Table (subquery ב-FROM):**
```sql
SELECT
    u.unit_id, u.unit_name, u.company,
    stats.soldier_count, stats.total_issues, stats.total_ammo_consumed,
    stats.first_issue_year, stats.last_issue_year
FROM UNIT u
JOIN (
    SELECT
        s2.unit_id,
        COUNT(DISTINCT s2.soldier_id) AS soldier_count,
        COUNT(ai2.issue_id)           AS total_issues,
        SUM(ai2.quantity)             AS total_ammo_consumed,
        EXTRACT(YEAR FROM MIN(ai2.issue_date)) AS first_issue_year,
        EXTRACT(YEAR FROM MAX(ai2.issue_date)) AS last_issue_year
    FROM SOLDIER s2
    JOIN AMMO_ISSUE ai2 ON s2.soldier_id = ai2.soldier_id
    GROUP BY s2.unit_id
    HAVING SUM(ai2.quantity) > (
        SELECT AVG(ut) FROM (
            SELECT SUM(ai3.quantity) AS ut
            FROM SOLDIER s3 JOIN AMMO_ISSUE ai3 ON s3.soldier_id = ai3.soldier_id
            GROUP BY s3.unit_id
        ) t
    )
) stats ON u.unit_id = stats.unit_id
ORDER BY stats.total_ammo_consumed DESC;
```

![Query 3B](screenshots/query_3b.png)

**הבדל ויעילות:**
- שתי הצורות יעילות דומות — ה-derived table מחושב פעם אחת בשתיהן.
- **צורה A** קצרה ובהירה יותר לקריאה.
- **צורה B** שימושית כאשר רוצים לשתף את ה-subquery בין חלקים שונים בשאילתה (למשל כ-CTE).
- PostgreSQL לרוב מייצר תוכנית ביצוע זהה לשתיהן.

---

### שאילתה 4 - חיילים המחזיקים נשק פעיל וקיבלו תחמושת ב-2024

**תיאור:** חיילים שמחזיקים נשק פעיל (return_date IS NULL) ושגם קיבלו תחמושת בשנת 2024. מציגה: שם, דרגה, יחידה, נשק, מספר ימי אחזקה, סך תחמושת ב-2024.

**צורה A – JOIN + DISTINCT ON + Window Functions:**
```sql
SELECT DISTINCT ON (s.soldier_id)
    s.soldier_id,
    s.first_name || ' ' || s.last_name         AS full_name,
    r.rank_name, u.unit_name,
    w.serial_number, w.model, wt.type_name     AS weapon_type,
    wa.assignment_date,
    CURRENT_DATE - wa.assignment_date           AS days_holding_weapon,
    SUM(ai.quantity) OVER (PARTITION BY s.soldier_id) AS ammo_received_in_2024,
    COUNT(ai.issue_id) OVER (PARTITION BY s.soldier_id) AS ammo_issues_in_2024
FROM SOLDIER s
JOIN RANK r ON s.rank_id = r.rank_id
JOIN UNIT u ON s.unit_id = u.unit_id
JOIN WEAPON_ASSIGNMENT wa ON s.soldier_id = wa.soldier_id AND wa.return_date IS NULL
JOIN WEAPON w ON wa.serial_number = w.serial_number
JOIN WEAPON_TYPE wt ON w.type_id = wt.type_id
JOIN AMMO_ISSUE ai ON s.soldier_id = ai.soldier_id
    AND EXTRACT(YEAR FROM ai.issue_date) = 2024
ORDER BY s.soldier_id, ammo_received_in_2024 DESC;
```

![Query 4A](screenshots/query_4a.png)

**צורה B – EXISTS Subquery:**
```sql
SELECT
    s.soldier_id,
    s.first_name || ' ' || s.last_name         AS full_name,
    r.rank_name, u.unit_name,
    w.serial_number, w.model, wt.type_name     AS weapon_type,
    wa.assignment_date,
    CURRENT_DATE - wa.assignment_date           AS days_holding_weapon
FROM SOLDIER s
JOIN RANK r ON s.rank_id = r.rank_id
JOIN UNIT u ON s.unit_id = u.unit_id
JOIN WEAPON_ASSIGNMENT wa ON s.soldier_id = wa.soldier_id
JOIN WEAPON w ON wa.serial_number = w.serial_number
JOIN WEAPON_TYPE wt ON w.type_id = wt.type_id
WHERE wa.return_date IS NULL
  AND EXISTS (
      SELECT 1 FROM AMMO_ISSUE ai
      WHERE ai.soldier_id = s.soldier_id
        AND EXTRACT(YEAR FROM ai.issue_date) = 2024
  )
ORDER BY wa.assignment_date;
```

![Query 4B](screenshots/query_4b.png)

**הבדל ויעילות:**
- **צורה A** מחשבת סיכומי תחמושת מלאים עם window functions — שימושית כשצריך את הכמויות.
- **צורה B** עם EXISTS עוצרת ברשומת התחמושת הראשונה שנמצאה — מהירה יותר כאשר רק צריך לדעת מי עומד בתנאי, ללא צורך בסיכומים.
- **בחר צורה A** כשצריך נתוני כמות. **בחר צורה B** כשרק צריך לזהות את החיילים הרלוונטיים.

---

## שאילתות SELECT נוספות

### שאילתה 5 - ספירת אחזקות חודשית לפי סוג נשק וסוג אחזקה

**תיאור:** מציגה עבור כל חודש ושנה את מספר האחזקות שבוצעו, לפי סוג הנשק וסוג האחזקה. כולל מספר נשקים ייחודיים שטופלו, מספר טכנאים, ויום מוקדם/מאוחר בחודש. שימושי לניתוח עומסי עבודה של הנשקייה.

```sql
SELECT
    wt.type_name                                AS weapon_type,
    mt.type_name                                AS maintenance_type,
    EXTRACT(YEAR  FROM m.maintenance_date)      AS maint_year,
    EXTRACT(MONTH FROM m.maintenance_date)      AS maint_month,
    COUNT(m.maintenance_id)                     AS maintenance_count,
    COUNT(DISTINCT m.serial_number)             AS weapons_serviced,
    COUNT(DISTINCT m.technician_id)             AS technicians_involved,
    MIN(EXTRACT(DAY FROM m.maintenance_date))   AS earliest_day_in_month,
    MAX(EXTRACT(DAY FROM m.maintenance_date))   AS latest_day_in_month
FROM MAINTENANCE m
JOIN WEAPON           w   ON m.serial_number  = w.serial_number
JOIN WEAPON_TYPE      wt  ON w.type_id        = wt.type_id
JOIN MAINTENANCE_TYPE mt  ON m.maint_type_id  = mt.maint_type_id
GROUP BY wt.type_name, mt.type_name,
         EXTRACT(YEAR  FROM m.maintenance_date),
         EXTRACT(MONTH FROM m.maintenance_date)
ORDER BY maint_year DESC, maint_month DESC, maintenance_count DESC;
```

![Query 5](screenshots/query_5.png)

---

### שאילתה 6 - נשקים שמעולם לא עברו אחזקה

**תיאור:** נשקים שאין להם אף רשומת אחזקה — סיכון בטיחותי. מציגה מספר סידורי, דגם, סוג, סטטוס, שנת ייצור, תאריך כניסה לשירות (שנה וחודש), מספר ימים בשירות, ומספר פעמים שהוקצה.

```sql
SELECT
    w.serial_number,
    w.model,
    wt.type_name                                AS weapon_type,
    ws.status_name                              AS current_status,
    w.manufacture_year,
    w.entry_date,
    EXTRACT(YEAR  FROM w.entry_date)            AS entry_year,
    EXTRACT(MONTH FROM w.entry_date)            AS entry_month,
    CURRENT_DATE - w.entry_date                 AS days_in_service,
    COUNT(wa.assignment_id)                     AS times_assigned
FROM WEAPON w
JOIN WEAPON_TYPE   wt  ON w.type_id   = wt.type_id
JOIN WEAPON_STATUS ws  ON w.status_id = ws.status_id
LEFT JOIN WEAPON_ASSIGNMENT wa ON w.serial_number = wa.serial_number
WHERE NOT EXISTS (
    SELECT 1 FROM MAINTENANCE m
    WHERE m.serial_number = w.serial_number
)
GROUP BY w.serial_number, w.model, wt.type_name, ws.status_name,
         w.manufacture_year, w.entry_date
ORDER BY days_in_service DESC;
```

![Query 6](screenshots/query_6.png)

---

### שאילתה 7 - 20 חיילים עם הזמן המצטבר הגבוה ביותר של אחזקת נשקים

**תיאור:** מחשבת לכל חייל את סך ימי האחזקה של נשקים (כולל נשקים שעדיין מוחזקים). מציגה שם, דרגה, יחידה, שנת גיוס, מספר הקצאות, סך ימים, שנת הקצאה ראשונה, ומספר נשקים פעילים כעת.

```sql
SELECT
    s.soldier_id,
    s.first_name || ' ' || s.last_name         AS full_name,
    r.rank_name,
    u.unit_name,
    EXTRACT(YEAR  FROM s.enlistment_date)       AS enlistment_year,
    EXTRACT(MONTH FROM s.enlistment_date)       AS enlistment_month,
    COUNT(wa.assignment_id)                     AS total_assignments,
    SUM(COALESCE(wa.return_date, CURRENT_DATE) - wa.assignment_date) AS total_days_held,
    EXTRACT(YEAR FROM MIN(wa.assignment_date))  AS first_assignment_year,
    COUNT(CASE WHEN wa.return_date IS NULL THEN 1 END) AS currently_holding
FROM SOLDIER s
JOIN RANK              r   ON s.rank_id    = r.rank_id
JOIN UNIT              u   ON s.unit_id    = u.unit_id
JOIN WEAPON_ASSIGNMENT wa  ON s.soldier_id = wa.soldier_id
GROUP BY s.soldier_id, s.first_name, s.last_name,
         r.rank_name, u.unit_name, s.enlistment_date
ORDER BY total_days_held DESC
LIMIT 20;
```

![Query 7](screenshots/query_7.png)

---

### שאילתה 8 - דוח התראות מלאי תחמושת מתחת למינימום

**תיאור:** תחמושת שמלאיה נמוך מהמינימום הנדרש. מציגה: סוג, קוטר, כמות במלאי, מינימום, גרעון, אחוז מהמינימום, תאריך הוצאה אחרון (שנה וחודש), וסך שהוצא ב-2024.

```sql
SELECT
    a.ammo_id, a.caliber, at2.type_name AS ammo_type,
    a.stock_quantity, a.minimum_stock,
    a.minimum_stock - a.stock_quantity  AS deficit,
    ROUND(a.stock_quantity::NUMERIC / NULLIF(a.minimum_stock, 0) * 100, 2) AS stock_pct,
    EXTRACT(YEAR  FROM COALESCE(recent.last_issue_date, DATE '1900-01-01')) AS last_issue_year,
    EXTRACT(MONTH FROM COALESCE(recent.last_issue_date, DATE '1900-01-01')) AS last_issue_month,
    COALESCE(recent.total_issued_this_year, 0) AS total_issued_in_2024
FROM AMMUNITION a
JOIN AMMO_TYPE at2 ON a.ammo_type_id = at2.ammo_type_id
LEFT JOIN (
    SELECT ammo_id, MAX(issue_date) AS last_issue_date,
        SUM(CASE WHEN EXTRACT(YEAR FROM issue_date) = 2024 THEN quantity ELSE 0 END) AS total_issued_this_year
    FROM AMMO_ISSUE GROUP BY ammo_id
) recent ON a.ammo_id = recent.ammo_id
WHERE a.stock_quantity < a.minimum_stock
ORDER BY deficit DESC;
```

![Query 8](screenshots/query_8.png)

---

## שאילתות DELETE

### Delete 1 - מחיקת רשומות הקצאה שהוחזרו לפני יותר מ-5 שנים

**תיאור:** ניקוי ארכיב — מחיקת רשומות WEAPON_ASSIGNMENT שבהן הנשק הוחזר לפני יותר מ-5 שנים ואין להן עוד ערך תפעולי.

```sql
DELETE FROM WEAPON_ASSIGNMENT
WHERE return_date IS NOT NULL
  AND return_date < CURRENT_DATE - INTERVAL '5 years';
```

![לפני המחיקה](screenshots/delete_1_before.png)
![אחרי המחיקה](screenshots/delete_1_after.png)

---

### Delete 2 - מחיקת רשומות הוצאת תחמושת לפני 2011

**תיאור:** ניקוי ארכיב — מחיקת רשומות AMMO_ISSUE ישנות מלפני שנת 2011 שאינן רלוונטיות עוד לפעילות השוטפת.

```sql
DELETE FROM AMMO_ISSUE
WHERE issue_date < DATE '2011-01-01';
```

![לפני המחיקה](screenshots/delete_2_before.png)
![אחרי המחיקה](screenshots/delete_2_after.png)

---

### Delete 3 - מחיקת רשומות אחזקה לנשקים מושבתים

**תיאור:** מחיקת רשומות MAINTENANCE ישנות (יותר מ-3 שנים) עבור נשקים שסטטוסם 'Decommissioned' — אין צורך לשמור היסטוריית אחזקה לנשקים שיצאו משירות.

```sql
DELETE FROM MAINTENANCE
WHERE maintenance_date < CURRENT_DATE - INTERVAL '3 years'
  AND serial_number IN (
      SELECT w.serial_number FROM WEAPON w
      JOIN WEAPON_STATUS ws ON w.status_id = ws.status_id
      WHERE ws.status_name = 'Decommissioned'
  );
```

![לפני המחיקה](screenshots/delete_3_before.png)
![אחרי המחיקה](screenshots/delete_3_after.png)

---

## שאילתות UPDATE

### Update 1 - סימון נשקים כ-'In Maintenance' אם לא טופלו ב-2 שנים

**תיאור:** נשקים שסטטוסם 'Operational' (status_id=1) אך לא עברו אחזקה ב-2 השנים האחרונות — מוחלף סטטוסם ל-'In Maintenance' (status_id=2) לצורך בדיקה.

```sql
UPDATE WEAPON
SET status_id = 2
WHERE status_id = 1
  AND serial_number NOT IN (
      SELECT serial_number FROM MAINTENANCE
      WHERE maintenance_date >= CURRENT_DATE - INTERVAL '2 years'
  );
```

![לפני העדכון](screenshots/update_1_before.png)
![אחרי העדכון](screenshots/update_1_after.png)

---

### Update 2 - הגדלת מלאי מינימום ב-20% לתחמושת בביקוש גבוה

**תיאור:** תחמושת שהוצאה יותר מ-50 פעמים סך הכל (פריטים בביקוש גבוה) מקבלת העלאה של 20% ב-minimum_stock כדי להבטיח מלאי מספק.

```sql
UPDATE AMMUNITION
SET minimum_stock = ROUND(minimum_stock * 1.20)
WHERE ammo_id IN (
    SELECT ammo_id FROM AMMO_ISSUE
    GROUP BY ammo_id
    HAVING COUNT(issue_id) > 50
);
```

![לפני העדכון](screenshots/update_2_before.png)
![אחרי העדכון](screenshots/update_2_after.png)

---

### Update 3 - תיקון ניסוח return_reason

**תיאור:** עדכון כל רשומות ההקצאה שבהן return_reason הוא 'Exercise ended' לניסוח רשמי יותר: 'Training Exercise Completed'.

```sql
UPDATE WEAPON_ASSIGNMENT
SET return_reason = 'Training Exercise Completed'
WHERE return_reason = 'Exercise ended';
```

![לפני העדכון](screenshots/update_3_before.png)
![אחרי העדכון](screenshots/update_3_after.png)

---

## אילוצים חדשים

### אילוץ 1 – entry_date לא לפני שנת הייצור

**תיאור השינוי:** הוספת אילוץ לטבלת WEAPON המוודא שתאריך הכניסה לשירות אינו קודם לתאריך 1 בינואר של שנת הייצור.

```sql
ALTER TABLE WEAPON
    ADD CONSTRAINT chk_entry_after_manufacture
    CHECK (entry_date >= (manufacture_year::TEXT || '-01-01')::DATE);
```

**ניסיון הפרה:** הכנסת נשק עם manufacture_year=2023 ו-entry_date=2020-06-01.

![constraint 1](screenshots/constraint_1.png)

---

### אילוץ 2 – מספר טלפון מתחיל ב-'0'

**תיאור השינוי:** הוספת אילוץ לטבלת SOLDIER המוודא שמספר הטלפון מתחיל ב-'0' בהתאם לפורמט הישראלי.

```sql
ALTER TABLE SOLDIER
    ADD CONSTRAINT chk_phone_starts_with_zero
    CHECK (phone LIKE '0%');
```

**ניסיון הפרה:** הכנסת חייל עם phone='5551234567'.

![constraint 2](screenshots/constraint_2.png)

---

### אילוץ 3 – purpose לא ריק ב-AMMO_ISSUE

**תיאור השינוי:** הוספת אילוץ לטבלת AMMO_ISSUE המוודא שלכל הוצאת תחמושת יש מטרה מתועדת ואינה ריקה או רווחים בלבד.

```sql
ALTER TABLE AMMO_ISSUE
    ADD CONSTRAINT chk_purpose_not_blank
    CHECK (LENGTH(TRIM(purpose)) > 0);
```

**ניסיון הפרה:** הכנסת רשומה עם purpose='   ' (רווחים בלבד).

![constraint 3](screenshots/constraint_3.png)

---

### אילוץ 4 – description ב-MAINTENANCE לפחות 10 תווים

**תיאור השינוי:** הוספת אילוץ לטבלת MAINTENANCE המוודא שתיאור האחזקה מכיל לפחות 10 תווים — תיעוד מינימלי משמעותי.

```sql
ALTER TABLE MAINTENANCE
    ADD CONSTRAINT chk_description_min_length
    CHECK (LENGTH(description) >= 10);
```

**ניסיון הפרה:** הכנסת רשומת אחזקה עם description='Fixed' (5 תווים בלבד).

![constraint 4](screenshots/constraint_4.png)

---

## Rollback ו-Commit

### הדגמת ROLLBACK

**תרחיש:** הוספת 5,000 יחידות למלאי תחמושת (ammo_id=1) בתוך transaction, לאחר מכן ביטול עם ROLLBACK.

| שלב | stock_quantity |
|---|---|
| אחרי UPDATE (בתוך transaction) | 41,941 |
| אחרי ROLLBACK | 36,941 (שוחזר!) |

![אחרי UPDATE](screenshots/rollback_after_update.png)
![אחרי ROLLBACK](screenshots/rollback_restored.png)

---

### הדגמת COMMIT

**תרחיש:** הגדלת minimum_stock ב-100 ליחידות תחמושת (ammo_id=1), לאחר מכן שמירה קבועה עם COMMIT.

| שלב | minimum_stock |
|---|---|
| אחרי UPDATE (בתוך transaction) | 600 |
| אחרי COMMIT | 600 (נשמר לצמיתות!) |

![תוצאת COMMIT](screenshots/commit_result.png)
