-- ============================================================
-- Iron Shield - Armory Management System
-- Phase B: Queries.sql
-- ============================================================
-- Contains:
--   8 SELECT queries (queries 1-4 each written in two forms)
--   3 DELETE queries
--   3 UPDATE queries
-- ============================================================


-- ============================================================
-- SELECT QUERIES
-- ============================================================


-- ============================================================
-- Query 1A: Soldiers who received more ammunition than the average soldier
-- Shows: soldier details, unit, total ammo, issue count, last activity
-- Method: JOIN + GROUP BY + scalar subquery in HAVING (computed once)
-- ============================================================
SELECT
    s.soldier_id,
    s.first_name || ' ' || s.last_name         AS full_name,
    r.rank_name,
    u.unit_name,
    SUM(ai.quantity)                            AS total_ammo_received,
    COUNT(ai.issue_id)                          AS number_of_issues,
    EXTRACT(YEAR  FROM MAX(ai.issue_date))      AS last_issue_year,
    EXTRACT(MONTH FROM MAX(ai.issue_date))      AS last_issue_month,
    EXTRACT(DAY   FROM MAX(ai.issue_date))      AS last_issue_day
FROM SOLDIER s
JOIN RANK       r   ON s.rank_id    = r.rank_id
JOIN UNIT       u   ON s.unit_id    = u.unit_id
JOIN AMMO_ISSUE ai  ON s.soldier_id = ai.soldier_id
GROUP BY s.soldier_id, s.first_name, s.last_name, r.rank_name, u.unit_name
HAVING SUM(ai.quantity) > (
    SELECT AVG(soldier_total)
    FROM (
        SELECT SUM(quantity) AS soldier_total
        FROM AMMO_ISSUE
        GROUP BY soldier_id
    ) sub
)
ORDER BY total_ammo_received DESC;

-- ============================================================
-- Query 1B: Same result - using correlated subquery in WHERE
-- Method: Correlated subqueries evaluated per-row (less efficient)
-- ============================================================
SELECT
    s.soldier_id,
    s.first_name || ' ' || s.last_name         AS full_name,
    r.rank_name,
    u.unit_name,
    (SELECT SUM(ai.quantity)   FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id) AS total_ammo_received,
    (SELECT COUNT(ai.issue_id) FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id) AS number_of_issues,
    EXTRACT(YEAR  FROM (SELECT MAX(ai.issue_date) FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id)) AS last_issue_year,
    EXTRACT(MONTH FROM (SELECT MAX(ai.issue_date) FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id)) AS last_issue_month
FROM SOLDIER s
JOIN RANK r ON s.rank_id = r.rank_id
JOIN UNIT u ON s.unit_id = u.unit_id
WHERE (SELECT SUM(ai.quantity) FROM AMMO_ISSUE ai WHERE ai.soldier_id = s.soldier_id) > (
    SELECT AVG(soldier_total)
    FROM (
        SELECT SUM(quantity) AS soldier_total
        FROM AMMO_ISSUE
        GROUP BY soldier_id
    ) avg_sub
)
ORDER BY total_ammo_received DESC;

-- EFFICIENCY COMPARISON 1A vs 1B:
-- 1A: GROUP BY is computed once; HAVING filters aggregated groups. Single pass over AMMO_ISSUE.
-- 1B: Each correlated subquery (SUM, COUNT, MAX) runs once per row in SOLDIER - 3 extra scans per soldier row.
-- For 700 soldiers with 20,000 ammo records, 1A is drastically faster than 1B.


-- ============================================================
-- Query 2A: Weapons assigned AND maintained in the same calendar year
-- Shows: weapon details, maintenance month, maintenance type, technician
-- Method: JOIN + EXISTS (avoids duplicate rows from multiple assignments)
-- ============================================================
SELECT
    w.serial_number,
    w.model,
    wt.type_name                                AS weapon_type,
    ws.status_name                              AS current_status,
    EXTRACT(YEAR  FROM m.maintenance_date)      AS activity_year,
    EXTRACT(MONTH FROM m.maintenance_date)      AS maintenance_month,
    mt.type_name                                AS maintenance_type,
    s.first_name || ' ' || s.last_name         AS technician_name
FROM WEAPON w
JOIN WEAPON_TYPE       wt  ON w.type_id        = wt.type_id
JOIN WEAPON_STATUS     ws  ON w.status_id      = ws.status_id
JOIN MAINTENANCE       m   ON w.serial_number  = m.serial_number
JOIN MAINTENANCE_TYPE  mt  ON m.maint_type_id  = mt.maint_type_id
JOIN SOLDIER           s   ON m.technician_id  = s.soldier_id
WHERE EXISTS (
    SELECT 1 FROM WEAPON_ASSIGNMENT wa
    WHERE wa.serial_number = w.serial_number
      AND EXTRACT(YEAR FROM wa.assignment_date) = EXTRACT(YEAR FROM m.maintenance_date)
)
ORDER BY activity_year DESC, w.serial_number;

-- ============================================================
-- Query 2B: Same using IN subqueries (less efficient)
-- Method: Two separate IN subqueries materialised independently
-- ============================================================
SELECT
    w.serial_number,
    w.model,
    wt.type_name       AS weapon_type,
    ws.status_name     AS current_status,
    m.maintenance_date,
    EXTRACT(YEAR  FROM m.maintenance_date) AS maintenance_year,
    EXTRACT(MONTH FROM m.maintenance_date) AS maintenance_month,
    mt.type_name       AS maintenance_type,
    m.description
FROM WEAPON w
JOIN WEAPON_TYPE      wt  ON w.type_id       = wt.type_id
JOIN WEAPON_STATUS    ws  ON w.status_id     = ws.status_id
JOIN MAINTENANCE      m   ON w.serial_number = m.serial_number
JOIN MAINTENANCE_TYPE mt  ON m.maint_type_id = mt.maint_type_id
WHERE w.serial_number IN (
    SELECT serial_number
    FROM WEAPON_ASSIGNMENT
    WHERE EXTRACT(YEAR FROM assignment_date) = EXTRACT(YEAR FROM m.maintenance_date)
)
ORDER BY maintenance_year DESC, w.serial_number;

-- EFFICIENCY COMPARISON 2A vs 2B:
-- 2A: Single join graph; the optimizer resolves all joins in one execution plan.
-- 2B: The IN subquery is correlated (references m.maintenance_date from outer query),
--     so it re-executes per maintenance row - effectively a nested loop with no index benefit.
-- 2A is clearly more efficient and also returns richer data (technician name).


-- ============================================================
-- Query 3A: Units with total ammunition consumption above average
-- Shows: unit stats, soldier count, date range of activity
-- Method: JOIN + GROUP BY + HAVING (single aggregation pass)
-- ============================================================
SELECT
    u.unit_id,
    u.unit_name,
    u.company,
    COUNT(DISTINCT s.soldier_id)                AS soldier_count,
    COUNT(ai.issue_id)                          AS total_issues,
    SUM(ai.quantity)                            AS total_ammo_consumed,
    EXTRACT(YEAR  FROM MIN(ai.issue_date))      AS first_issue_year,
    EXTRACT(MONTH FROM MIN(ai.issue_date))      AS first_issue_month,
    EXTRACT(YEAR  FROM MAX(ai.issue_date))      AS last_issue_year,
    EXTRACT(MONTH FROM MAX(ai.issue_date))      AS last_issue_month
FROM UNIT u
JOIN SOLDIER    s   ON u.unit_id    = s.unit_id
JOIN AMMO_ISSUE ai  ON s.soldier_id = ai.soldier_id
GROUP BY u.unit_id, u.unit_name, u.company
HAVING SUM(ai.quantity) > (
    SELECT AVG(unit_total) FROM (
        SELECT SUM(ai2.quantity) AS unit_total
        FROM SOLDIER s2
        JOIN AMMO_ISSUE ai2 ON s2.soldier_id = ai2.soldier_id
        GROUP BY s2.unit_id
    ) unit_sub
)
ORDER BY total_ammo_consumed DESC;

-- ============================================================
-- Query 3B: Same using a derived table subquery (JOIN to subquery)
-- Method: Pre-aggregate in subquery, then join to UNIT
-- ============================================================
SELECT
    u.unit_id,
    u.unit_name,
    u.company,
    stats.soldier_count,
    stats.total_issues,
    stats.total_ammo_consumed,
    stats.first_issue_year,
    stats.first_issue_month,
    stats.last_issue_year,
    stats.last_issue_month
FROM UNIT u
JOIN (
    SELECT
        s2.unit_id,
        COUNT(DISTINCT s2.soldier_id)               AS soldier_count,
        COUNT(ai2.issue_id)                         AS total_issues,
        SUM(ai2.quantity)                           AS total_ammo_consumed,
        EXTRACT(YEAR  FROM MIN(ai2.issue_date))     AS first_issue_year,
        EXTRACT(MONTH FROM MIN(ai2.issue_date))     AS first_issue_month,
        EXTRACT(YEAR  FROM MAX(ai2.issue_date))     AS last_issue_year,
        EXTRACT(MONTH FROM MAX(ai2.issue_date))     AS last_issue_month
    FROM SOLDIER s2
    JOIN AMMO_ISSUE ai2 ON s2.soldier_id = ai2.soldier_id
    GROUP BY s2.unit_id
    HAVING SUM(ai2.quantity) > (
        SELECT AVG(ut) FROM (
            SELECT SUM(ai3.quantity) AS ut
            FROM SOLDIER s3 JOIN AMMO_ISSUE ai3 ON s3.soldier_id = ai3.soldier_id
            GROUP BY s3.unit_id
        ) t
    )
) stats ON u.unit_id = stats.unit_id
ORDER BY stats.total_ammo_consumed DESC;

-- EFFICIENCY COMPARISON 3A vs 3B:
-- Both are similar in performance because the derived table is computed once.
-- 3A is cleaner and easier to read. 3B demonstrates the derived-table pattern explicitly.
-- PostgreSQL's optimizer often transforms them into equivalent plans.
-- 3A is preferred for readability; 3B can be useful when the subquery is reused.


-- ============================================================
-- Query 4A: Soldiers currently holding a weapon AND who received
-- ammunition in 2024 - one row per soldier with ammo totals
-- Method: Multiple JOINs + DISTINCT ON + window functions
-- ============================================================
SELECT DISTINCT ON (s.soldier_id)
    s.soldier_id,
    s.first_name || ' ' || s.last_name         AS full_name,
    r.rank_name,
    u.unit_name,
    w.serial_number,
    w.model,
    wt.type_name                                AS weapon_type,
    wa.assignment_date,
    CURRENT_DATE - wa.assignment_date           AS days_holding_weapon,
    SUM(ai.quantity) OVER (PARTITION BY s.soldier_id) AS ammo_received_in_2024,
    COUNT(ai.issue_id) OVER (PARTITION BY s.soldier_id) AS ammo_issues_in_2024
FROM SOLDIER s
JOIN RANK              r   ON s.rank_id        = r.rank_id
JOIN UNIT              u   ON s.unit_id        = u.unit_id
JOIN WEAPON_ASSIGNMENT wa  ON s.soldier_id     = wa.soldier_id
    AND wa.return_date IS NULL
JOIN WEAPON            w   ON wa.serial_number = w.serial_number
JOIN WEAPON_TYPE       wt  ON w.type_id        = wt.type_id
JOIN AMMO_ISSUE        ai  ON s.soldier_id     = ai.soldier_id
    AND EXTRACT(YEAR FROM ai.issue_date) = 2024
ORDER BY s.soldier_id, ammo_received_in_2024 DESC;

-- ============================================================
-- Query 4B: Same existence check using EXISTS subquery
-- Method: EXISTS stops at first match - efficient for checking presence only
-- ============================================================
SELECT
    s.soldier_id,
    s.first_name || ' ' || s.last_name         AS full_name,
    r.rank_name,
    u.unit_name,
    w.serial_number,
    w.model,
    wt.type_name                                AS weapon_type,
    wa.assignment_date,
    CURRENT_DATE - wa.assignment_date           AS days_holding_weapon
FROM SOLDIER s
JOIN RANK              r   ON s.rank_id       = r.rank_id
JOIN UNIT              u   ON s.unit_id       = u.unit_id
JOIN WEAPON_ASSIGNMENT wa  ON s.soldier_id    = wa.soldier_id
JOIN WEAPON            w   ON wa.serial_number = w.serial_number
JOIN WEAPON_TYPE       wt  ON w.type_id       = wt.type_id
WHERE wa.return_date IS NULL
  AND EXISTS (
      SELECT 1 FROM AMMO_ISSUE ai
      WHERE ai.soldier_id = s.soldier_id
        AND EXTRACT(YEAR FROM ai.issue_date) = EXTRACT(YEAR FROM CURRENT_DATE)
  )
ORDER BY wa.assignment_date;

-- EFFICIENCY COMPARISON 4A vs 4B:
-- 4A: Requires full GROUP BY aggregation over potentially large result set.
--     Useful when you need the ammo totals.
-- 4B: EXISTS short-circuits after finding the first matching ammo record per soldier,
--     making it faster when only the existence check is needed (no aggregate needed).
-- Use 4A when you need the SUM/COUNT. Use 4B when you only need to identify who qualifies.


-- ============================================================
-- Query 5: Monthly maintenance count by weapon type and year
-- Demonstrates EXTRACT on day/month/year from DATE field
-- ============================================================
SELECT
    wt.type_name                                AS weapon_type,
    mt.type_name                                AS maintenance_type,
    EXTRACT(YEAR  FROM m.maintenance_date)      AS maint_year,
    EXTRACT(MONTH FROM m.maintenance_date)      AS maint_month,
    COUNT(m.maintenance_id)                     AS maintenance_count,
    COUNT(DISTINCT m.serial_number)             AS weapons_serviced,
    COUNT(DISTINCT m.technician_id)             AS technicians_involved,
    MIN(EXTRACT(DAY FROM m.maintenance_date))   AS earliest_day_in_month,
    MAX(EXTRACT(DAY FROM m.maintenance_date))   AS latest_day_in_month
FROM MAINTENANCE m
JOIN WEAPON           w   ON m.serial_number  = w.serial_number
JOIN WEAPON_TYPE      wt  ON w.type_id        = wt.type_id
JOIN MAINTENANCE_TYPE mt  ON m.maint_type_id  = mt.maint_type_id
GROUP BY wt.type_name, mt.type_name,
         EXTRACT(YEAR  FROM m.maintenance_date),
         EXTRACT(MONTH FROM m.maintenance_date)
ORDER BY maint_year DESC, maint_month DESC, maintenance_count DESC;


-- ============================================================
-- Query 6: Weapons that have NEVER been sent for maintenance
-- Potential safety risk - weapons in service with no service history
-- ============================================================
SELECT
    w.serial_number,
    w.model,
    wt.type_name                                AS weapon_type,
    ws.status_name                              AS current_status,
    w.manufacture_year,
    w.entry_date,
    EXTRACT(YEAR  FROM w.entry_date)            AS entry_year,
    EXTRACT(MONTH FROM w.entry_date)            AS entry_month,
    CURRENT_DATE - w.entry_date                 AS days_in_service,
    COUNT(wa.assignment_id)                     AS times_assigned
FROM WEAPON w
JOIN WEAPON_TYPE   wt  ON w.type_id   = wt.type_id
JOIN WEAPON_STATUS ws  ON w.status_id = ws.status_id
LEFT JOIN WEAPON_ASSIGNMENT wa ON w.serial_number = wa.serial_number
WHERE NOT EXISTS (
    SELECT 1 FROM MAINTENANCE m
    WHERE m.serial_number = w.serial_number
)
GROUP BY w.serial_number, w.model, wt.type_name, ws.status_name,
         w.manufacture_year, w.entry_date
ORDER BY days_in_service DESC;


-- ============================================================
-- Query 7: Top 20 soldiers by cumulative days holding weapons
-- Uses date arithmetic to calculate total holding time
-- ============================================================
SELECT
    s.soldier_id,
    s.first_name || ' ' || s.last_name         AS full_name,
    r.rank_name,
    u.unit_name,
    s.enlistment_date,
    EXTRACT(YEAR  FROM s.enlistment_date)       AS enlistment_year,
    EXTRACT(MONTH FROM s.enlistment_date)       AS enlistment_month,
    COUNT(wa.assignment_id)                     AS total_assignments,
    SUM(COALESCE(wa.return_date, CURRENT_DATE) - wa.assignment_date) AS total_days_held,
    MIN(wa.assignment_date)                     AS first_assignment_date,
    EXTRACT(YEAR FROM MIN(wa.assignment_date))  AS first_assignment_year,
    MAX(COALESCE(wa.return_date, CURRENT_DATE)) AS last_weapon_date,
    COUNT(CASE WHEN wa.return_date IS NULL THEN 1 END) AS currently_holding
FROM SOLDIER s
JOIN RANK              r   ON s.rank_id    = r.rank_id
JOIN UNIT              u   ON s.unit_id    = u.unit_id
JOIN WEAPON_ASSIGNMENT wa  ON s.soldier_id = wa.soldier_id
GROUP BY s.soldier_id, s.first_name, s.last_name,
         r.rank_name, u.unit_name, s.enlistment_date
ORDER BY total_days_held DESC
LIMIT 20;


-- ============================================================
-- Query 8: Ammunition stock alert report
-- Shows items below minimum stock with consumption trend
-- ============================================================
SELECT
    a.ammo_id,
    a.caliber,
    at2.type_name                                               AS ammo_type,
    a.stock_quantity,
    a.minimum_stock,
    a.minimum_stock - a.stock_quantity                          AS deficit,
    ROUND(
        a.stock_quantity::NUMERIC / NULLIF(a.minimum_stock, 0) * 100, 2
    )                                                           AS stock_pct,
    COALESCE(recent.last_issue_date, DATE '1900-01-01')         AS last_issue_date,
    EXTRACT(YEAR  FROM COALESCE(recent.last_issue_date, DATE '1900-01-01')) AS last_issue_year,
    EXTRACT(MONTH FROM COALESCE(recent.last_issue_date, DATE '1900-01-01')) AS last_issue_month,
    COALESCE(recent.total_issued_this_year, 0)                  AS total_issued_this_year,
    COALESCE(recent.issue_count_this_year, 0)                   AS issue_count_this_year
FROM AMMUNITION a
JOIN AMMO_TYPE at2 ON a.ammo_type_id = at2.ammo_type_id
LEFT JOIN (
    SELECT
        ammo_id,
        MAX(issue_date)     AS last_issue_date,
        SUM(CASE WHEN EXTRACT(YEAR FROM issue_date) = EXTRACT(YEAR FROM CURRENT_DATE)
                 THEN quantity ELSE 0 END)  AS total_issued_this_year,
        COUNT(CASE WHEN EXTRACT(YEAR FROM issue_date) = EXTRACT(YEAR FROM CURRENT_DATE)
                   THEN 1 END)             AS issue_count_this_year
    FROM AMMO_ISSUE
    GROUP BY ammo_id
) recent ON a.ammo_id = recent.ammo_id
WHERE a.stock_quantity < a.minimum_stock
ORDER BY deficit DESC;


-- ============================================================
-- DELETE QUERIES (3)
-- ============================================================

-- ============================================================
-- Delete 1: Remove weapon assignment records where the weapon was
-- returned more than 5 years ago (archival / data retention cleanup)
-- ============================================================
DELETE FROM WEAPON_ASSIGNMENT
WHERE return_date IS NOT NULL
  AND return_date < CURRENT_DATE - INTERVAL '5 years';

-- ============================================================
-- Delete 2: Remove old ammunition issue records from before 2011
-- Archival cleanup of early data no longer operationally relevant
-- ============================================================
DELETE FROM AMMO_ISSUE
WHERE issue_date < DATE '2011-01-01';

-- ============================================================
-- Delete 3: Remove maintenance records for Decommissioned weapons
-- that are older than 3 years (no longer operationally relevant)
-- ============================================================
DELETE FROM MAINTENANCE
WHERE maintenance_date < CURRENT_DATE - INTERVAL '3 years'
  AND serial_number IN (
      SELECT w.serial_number
      FROM WEAPON w
      JOIN WEAPON_STATUS ws ON w.status_id = ws.status_id
      WHERE ws.status_name = 'Decommissioned'
  );


-- ============================================================
-- UPDATE QUERIES (3)
-- ============================================================

-- ============================================================
-- Update 1: Flag weapons as 'In Maintenance' if they have not
-- been serviced in over 2 years and are currently 'Operational'
-- ============================================================
UPDATE WEAPON
SET status_id = 2
WHERE status_id = 1
  AND serial_number NOT IN (
      SELECT serial_number
      FROM MAINTENANCE
      WHERE maintenance_date >= CURRENT_DATE - INTERVAL '2 years'
  );

-- ============================================================
-- Update 2: Increase minimum stock by 20% for ammunition that
-- has been issued more than 50 times in total (high-demand items)
-- ============================================================
UPDATE AMMUNITION
SET minimum_stock = ROUND(minimum_stock * 1.20)
WHERE ammo_id IN (
    SELECT ammo_id
    FROM AMMO_ISSUE
    GROUP BY ammo_id
    HAVING COUNT(issue_id) > 50
);

-- ============================================================
-- Update 3: Standardize return_reason from 'Exercise ended'
-- to the more formal 'Training Exercise Completed'
-- ============================================================
UPDATE WEAPON_ASSIGNMENT
SET return_reason = 'Training Exercise Completed'
WHERE return_reason = 'Exercise ended';
