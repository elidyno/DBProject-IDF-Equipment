-- ============================================================
-- Iron Shield - Armory Management System
-- Phase B: Constraints.sql
-- ============================================================
-- Adds new constraints to existing tables using ALTER TABLE.
-- Each constraint is followed by an example that violates it
-- to demonstrate the error is raised correctly.
-- ============================================================


-- ============================================================
-- Constraint 1: Weapon entry_date must be on or after Jan 1
--               of its manufacture_year
-- Rationale: A weapon cannot enter service before it was made
-- ============================================================

-- Fix existing data before adding constraint
UPDATE WEAPON
SET entry_date = (manufacture_year::TEXT || '-01-01')::DATE
WHERE entry_date < (manufacture_year::TEXT || '-01-01')::DATE;

ALTER TABLE WEAPON
    ADD CONSTRAINT chk_entry_after_manufacture
    CHECK (entry_date >= (manufacture_year::TEXT || '-01-01')::DATE);

-- Violation test (should raise error):
-- INSERT INTO WEAPON (serial_number, model, manufacture_year, entry_date, type_id, status_id)
-- VALUES ('VIOL-001', 'Test Rifle', 2023, DATE '2020-06-01', 1, 1);
-- ERROR: new row violates check constraint "chk_entry_after_manufacture"
-- (entry_date 2020 is before manufacture_year 2023)


-- ============================================================
-- Constraint 2: Soldier phone must start with '0'
-- Rationale: All Israeli phone numbers begin with 0
-- ============================================================

ALTER TABLE SOLDIER
    ADD CONSTRAINT chk_phone_starts_with_zero
    CHECK (phone LIKE '0%');

-- Violation test (should raise error):
-- INSERT INTO SOLDIER (soldier_id, first_name, last_name, enlistment_date, phone, rank_id, unit_id)
-- VALUES (999991, 'Test', 'Violation', DATE '2020-01-01', '5551234567', 1, 1);
-- ERROR: new row violates check constraint "chk_phone_starts_with_zero"
-- (phone '5551234567' does not start with '0')


-- ============================================================
-- Constraint 3: AMMO_ISSUE purpose must not be blank/whitespace
-- Rationale: Every ammunition issue must have a documented reason
-- ============================================================

ALTER TABLE AMMO_ISSUE
    ADD CONSTRAINT chk_purpose_not_blank
    CHECK (LENGTH(TRIM(purpose)) > 0);

-- Violation test (should raise error):
-- INSERT INTO AMMO_ISSUE (issue_id, quantity, issue_date, purpose, soldier_id, ammo_id)
-- VALUES (999991, 50, CURRENT_DATE, '   ', 1, 1);
-- ERROR: new row violates check constraint "chk_purpose_not_blank"
-- (purpose contains only whitespace)


-- ============================================================
-- Constraint 4: MAINTENANCE description must be at least 10 chars
-- Rationale: Maintenance records require meaningful documentation
-- ============================================================

ALTER TABLE MAINTENANCE
    ADD CONSTRAINT chk_description_min_length
    CHECK (LENGTH(description) >= 10);

-- Violation test (should raise error):
-- INSERT INTO MAINTENANCE
--   (maintenance_id, maintenance_date, description, status_after, serial_number, technician_id, maint_type_id)
-- SELECT
--   999991, CURRENT_DATE, 'Fixed', 'OK',
--   serial_number, soldier_id, 1
-- FROM WEAPON CROSS JOIN SOLDIER LIMIT 1;
-- ERROR: new row violates check constraint "chk_description_min_length"
-- (description 'Fixed' has only 5 characters, minimum is 10)
